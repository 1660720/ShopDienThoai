<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Footer</title>
	<style type="text/css">
		.footer1 {
			background-color: #171515;
			border: 1px solid red;
			width: 100%;
			height: 45px;
			padding-top: 0px;
		}
		.footer1 p{
			color: red;
			text-align: center;
			font-size: 17px;
		}
	</style>
</head>
<body>
	<div class="footer1">
		<p>160648 -1660720-1660038</p>
	</div>
</body>
</html>