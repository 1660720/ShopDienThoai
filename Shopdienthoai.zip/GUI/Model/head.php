<head xmlns="http://www.w3.org/1999/xhtml">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>SanPhamCongNghe.com</title>
    <link rel="stylesheet"type="text/css" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css">
    <!--<link rel="stylesheet"type="text/css" href="GUI/font-awesome/css/font-awesome.css">-->
    <link rel="stylesheet" type="text/css" href="GUI/css/style.css">
</head>