
            <div id="sidebar">
                <!---->
                <div class="slide">
                <div class="dieukhien">
                <i class="fas fa-angle-left"  onclick="Back();"></i>
                <i class="fas fa-angle-right" onclick="Next();"></i>
                </div>
                <div class="chuyen-slide">
                   <img src="GUI/img/slidebar1.png">
                   <img src="GUI/img/slidebar2.png">
                   <img src="GUI/img/slidebar3.png"> 
                   <img src="GUI/img/slidebar4.png"> 
                   <img src="GUI/img/slidebar5.png"> 
                </div>
            </div>
            <script type="text/javascript" src="GUI/js/sidebar.js"></script>
            <div class="quangcaotop">
            <img src="GUI/img/slidebar7.png">
            </div>
            <div class="quangcaobottom">
            <img src="GUI/img/slidebar8.png">
            </div>
            <div class="quangcaofinish">
            <img src="GUI/img/slidebar9.png">
            </div>
             
            <table class="clickdichuyen" rules="cols">
                <tr>
                    <td onclick="vitri(1);">Đặt xiaomi Mi 8 Pro <br> 200 Suất Quà Ngon</td>
                    <td onclick="vitri(2);">Sở Hữu iphone Mới <br> Giảm Đến 2 Triệu</td>
                    <td onclick="vitri(3);">Realme C1 Giá Ngon <br> Chỉ 2.490.000đ</td>
                    <td onclick="vitri(4);">Thu Cũ Lên Đời Note 9 <br> Trợ Giá 10 Triệu</td>
                    <td onclick="vitri(5);">Đặt Trước Galaxy A9 <br> Tặng quà 6 Triệu</td>
                </tr>
            </table>
            <script type="text/javascript" src="GUI/js/sidebar.js"></script>
            <div class="quangcao">
                <img src="GUI/img/slidebar6.png">
            </div>
            </div>